
from cc3d.core.PySteppables import *

class GrowthSteppableSteppable(SteppableBasePy):

    def __init__(self,frequency=1):

        SteppableBasePy.__init__(self,frequency)

    def start(self):
        for cell in self.cell_list:
            cell.targetVolume = 25.0
            cell.lambdaVolume = 2.0

    def step(self,mcs):
        """
        type here the code that will run every frequency MCS
        :param mcs: current Monte Carlo step
        """

    def finish(self):
        """
        Finish Function is called after the last MCS
        """


        