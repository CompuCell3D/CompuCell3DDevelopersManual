from cc3d import CompuCellSetup
        
CompuCellSetup.run()
