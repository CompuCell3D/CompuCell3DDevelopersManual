
from cc3d import CompuCellSetup
        

from GrowthSteppableSteppables import GrowthSteppableSteppable

CompuCellSetup.register_steppable(steppable=GrowthSteppableSteppable(frequency=1))


CompuCellSetup.run()
